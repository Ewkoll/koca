#!/usr/bin/env python
# -*- coding: utf-8 -*-
'''
@Description: 
@Author: ideath@operatorworld.com
@Date: 2019-06-27 09:47:29
@LastEditors: ideath
@LastEditTime: 2019-06-27 09:58:39
'''
from .index import main
